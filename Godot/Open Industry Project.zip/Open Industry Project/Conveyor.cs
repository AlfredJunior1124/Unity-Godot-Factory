using Godot;
using System;
using System.Threading.Tasks;

[Tool]
public partial class Conveyor : Node3D
{
    [Export]

    public bool enableComms = false;

    [Export]
	public string tagName;

	[Export]
	public float Speed = -1f;

	private Vector3 origin;
	private bool initalize = true;
	readonly Guid id = Guid.NewGuid();
	Root root = new();
	double scan_interval = 0;
	public override void _Process(double delta)
	{
		root = GetNode<Root>("..");
		var rb = GetNode<RigidBody3D>("RigidBody3D");
		var mesh = GetNode<MeshInstance3D>("RigidBody3D/MeshInstance3D");
		var collision = GetNode<CollisionShape3D>("RigidBody3D/CollisionShape3D");
		var box = (BoxShape3D)collision.Shape;

		if (root.Start)
		{
			mesh.Position = rb.Position;
			mesh.Rotation = rb.Rotation;
			rb.Freeze = false;
			GetNode(".").SetMeta("_edit_lock_", false);
			
			if (initalize)
			{
				GetNode(".").RemoveMeta("_edit_lock_");
				root.Connect(id, tagName);
				origin = rb.Position;
				initalize = false;
			}
			var localLeft = -rb.GlobalTransform.Basis.Z;
			var velocity = localLeft * Speed;
			rb.LinearVelocity = velocity;
			rb.Position = origin;
			if(enableComms)
			{
                scan_interval += delta;
                if (scan_interval > 0.25)
                {
                    scan_interval = 0;
                    Task.Run(ScanTag);
                }
            }
		}
		else
		{
			mesh.Position = Position;
			mesh.Rotation = Rotation;
			rb.Position = Position;
			rb.Rotation = Rotation;
			box.Size = Scale;
			mesh.Scale = Scale;
			rb.Freeze = true;
			rb.LinearVelocity = Vector3.Zero;
			GetNode(".").RemoveMeta("_edit_lock_");
			initalize = true;
		}
	}

	async Task ScanTag()
	{
		try
		{
			Speed = await root.ReadFloat(id);
		}
		catch (Exception ex)
		{
			GD.Print(ex.Message);
		}

	}
}

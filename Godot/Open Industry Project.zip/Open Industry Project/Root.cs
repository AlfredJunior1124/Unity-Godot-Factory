using Godot;
using libplctag;
using libplctag.DataTypes;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

[Tool]
public partial class Root : Node3D
{
	[Export]
	public bool Start { get; set; } = false;

	[Export]
	public string Gateway { get; set; }

	[Export]
	public string Path { get; set; }

	[Export]

	public PlcType PlcType { get; set; } = PlcType.ControlLogix;

	[Export]

	public Protocol Protocol { get; set; } = Protocol.ab_eip;

	readonly Dictionary<Guid, Tag<RealPlcMapper, float>> float_tags = new();

	bool inialized = false;

	public void Connect(Guid guid, string tagName)
	{
		Tag<RealPlcMapper, float> tag = new()
		{
			Name = tagName,
			Gateway = Gateway,
			Path = Path,
			PlcType = PlcType,
			Protocol = Protocol,
			Timeout = TimeSpan.FromSeconds(5)
		};

		float_tags.Add(guid, tag);
	}

	public async Task<float> ReadFloat(Guid guid)
	{
		try
		{
			return (float)(await float_tags[guid].ReadAsync());
		}
		catch(Exception ex)
		{
			GD.Print(ex.Message);
			return 0;
		}
	}

	public override void _Process(double delta)
	{
		if (Input.IsActionJustPressed("ui_home"))
		{
			Start = !Start;
		}

		if (Start)
		{
			if (!inialized)
			{
				PhysicsServer3D.SetActive(true);
				inialized = true;
			}
		}
		else
		{
			if (inialized)
			{
				PhysicsServer3D.SetActive(false);
				float_tags.Clear();
				inialized = false;
			}
		}
	}
}

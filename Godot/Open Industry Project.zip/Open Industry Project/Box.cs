using Godot;

[Tool]
public partial class Box : Node3D
{
	public override void _Process(double delta)
	{

		Root root = GetNode<Root>("..");
		var rb = GetNode<RigidBody3D>("RigidBody3D");
		var mesh = GetNode<MeshInstance3D>("RigidBody3D/MeshInstance3D");
		var collision = GetNode<CollisionShape3D>("RigidBody3D/CollisionShape3D");
		var box = (BoxShape3D)collision.Shape;

		if (root.Start)
		{
			mesh.Position = rb.Position;
			mesh.Rotation = rb.Rotation;
			Position = rb.Position;
			Rotation = rb.Rotation;
            rb.Freeze = false;
            GetNode(".").SetMeta("_edit_lock_", false);

        }
		else
		{
			mesh.Position = Position;
			mesh.Rotation = Rotation;
			rb.Position = Position;
			rb.Rotation = Rotation;
			box.Size = Scale;
			mesh.Scale = Scale;
			rb.Freeze = true;
            GetNode(".").RemoveMeta("_edit_lock_");
        }
	}
}
